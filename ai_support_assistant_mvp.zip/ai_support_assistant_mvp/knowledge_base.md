# Product & Troubleshooting KB

## Login Issues
- If a user cannot access the dashboard or login fails, recommend clearing cache/cookies, trying an incognito window, and resetting the password.
- Known incident: 500 error on /auth from 2025-09-03 10:00–12:30 UTC, resolved. If similar, ask for exact timestamp and org ID to check logs.

## Billing & Refunds
- Refunds take 5–7 business days. Ask for order ID and last 4 digits of the card.
- Payment failures: suggest checking card limits, retrying after 10 minutes, or using an alternate method.

## Data Export
- Exports are emailed within 30 minutes. Larger exports may take up to 2 hours.
- If not received, confirm spam/junk and allowlist support@company.com.

## Security
- For suspected breach or account compromise, immediately enforce password reset and enable 2FA. Escalate to security@company.com with user’s consent.
