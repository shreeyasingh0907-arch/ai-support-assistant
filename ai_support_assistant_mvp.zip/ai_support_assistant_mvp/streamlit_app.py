
import streamlit as st
import pandas as pd
import re, math
from datetime import datetime
from pathlib import Path

SUPPORT_SUBJECT_RE = re.compile(r"\b(support|query|request|help)\b", re.I)
STRONG_URGENT_RE = re.compile(r"\b(immediately|urgent|cannot access|down|critical|security|breach|production|escalate)\b", re.I)
MEDIUM_URGENT_RE = re.compile(r"\b(asap|not working|blocked|crash|deadline|refund|payment failed)\b", re.I)
PHONE_RE = re.compile(r"\+?\d[\d\-\s()]{7,}\b")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")

NEGATIVE_WORDS = set("angry frustrated disappointed terrible bad worst useless unacceptable not working cannot can't failed failure error crash down urgent immediately escalate".split())
POSITIVE_WORDS = set("thanks thank you appreciate great awesome good love happy resolved works working".split())

def simple_sentiment(text: str) -> str:
    text_l = text.lower()
    pos = sum(1 for w in POSITIVE_WORDS if w in text_l)
    neg = sum(1 for w in NEGATIVE_WORDS if w in text_l)
    if neg > pos and neg > 0: return "negative"
    if pos > neg and pos > 0: return "positive"
    return "neutral"

def priority_score(text: str, sentiment: str) -> tuple[str, int]:
    strong = bool(STRONG_URGENT_RE.search(text))
    medium = bool(MEDIUM_URGENT_RE.search(text))
    score = 100 if strong else 60 if medium else 20
    if sentiment == "negative":
        score += 20
    priority = "urgent" if score >= 70 else "not_urgent"
    return priority, score

def extract_info(text: str, from_addr: str) -> dict:
    phone = None
    m = PHONE_RE.search(text)
    if m: phone = m.group(0)
    emails = [e for e in set(EMAIL_RE.findall(text)) if e.lower() != from_addr.lower()]
    alt_email = emails[0] if emails else None
    # naive requirements: take first 30 words beyond greetings
    body_words = re.sub(r"\s+", " ", text).strip().split()
    requirements = " ".join(body_words[:30])
    return {"phone": phone, "alt_email": alt_email, "requirements": requirements}

def load_kb(kb_path: Path) -> list[str]:
    if not kb_path.exists(): return []
    chunks = []
    current = []
    for line in kb_path.read_text(encoding="utf-8").splitlines():
        if line.startswith("## "):
            if current:
                chunks.append("\n".join(current).strip())
                current = []
        current.append(line)
    if current: chunks.append("\n".join(current).strip())
    return chunks

def retrieve_kb_snippets(kb_chunks: list[str], query: str, k: int = 3) -> list[str]:
    # Super simple retrieval: rank by keyword overlap
    q = set(re.findall(r"[a-zA-Z]{3,}", query.lower()))
    scored = []
    for ch in kb_chunks:
        c = set(re.findall(r"[a-zA-Z]{3,}", ch.lower()))
        overlap = len(q & c)
        scored.append((overlap, ch))
    scored.sort(reverse=True, key=lambda x: x[0])
    return [ch for ov, ch in scored[:k] if ov > 0] or kb_chunks[:1]

def draft_reply(email, snippets: list[str]) -> str:
    greeting = f"Hi {email.get('from_addr').split('@')[0].title()},"
    opener = "Thanks for reaching out."
    if email.get("sentiment") == "negative":
        opener = "I'm sorry you're experiencing this—thanks for your patience while we help."
    steps = []
    subj_body = (email.get("subject","") + " " + email.get("body","")).lower()
    if "login" in subj_body or "access" in subj_body:
        steps.append("Try clearing cache/cookies or using an incognito window, then retry login.")
        steps.append("If it persists, please share the exact timestamp and any error message.")
    if "refund" in subj_body or "payment" in subj_body:
        steps.append("Refunds typically complete in 5–7 business days; please share your order ID.")
    if "export" in subj_body:
        steps.append("Exports are usually delivered within 30 minutes; please check spam/junk as well.")
    if not steps:
        steps.append("Could you share any error message, your org/account ID, and the time it occurred?")
    if email.get("priority") == "urgent":
        steps.insert(0, "As an immediate step, we've flagged this as urgent. We'll monitor and keep you updated.")

    kb_block = "\n".join(f"- {s.splitlines()[0].lstrip('# ').strip()}" for s in snippets)
    body = f"""{greeting}

{opener}

Here are a few steps to move forward:
""" + "\n".join([f"{i+1}. {s}" for i, s in enumerate(steps)]) + f"""

Context we considered:
{kb_block}

If you're still blocked, reply to this email and we'll escalate to a specialist.
Best regards,
Support Team
"""

    return body.strip()

def normalize_input_df(df: pd.DataFrame) -> pd.DataFrame:
    # Expected columns: sender/from, subject, body/content, received_at/date
    # Try to map common names
    col_map = {}
    for c in df.columns:
        cl = c.strip().lower()
        if cl in ("from","from_addr","sender","email_from","sender_email"): col_map[c] = "from_addr"
        elif cl in ("subject","title"): col_map[c] = "subject"
        elif cl in ("body","content","email_body","message"): col_map[c] = "body"
        elif cl in ("date","datetime","received_at","timestamp","time"): col_map[c] = "received_at"
    df = df.rename(columns=col_map)
    for col in ["from_addr","subject","body"]:
        if col not in df: df[col] = ""
    if "received_at" not in df: df["received_at"] = pd.Timestamp.utcnow()
    return df[["from_addr","subject","body","received_at"]]

st.set_page_config(page_title="AI Support Assistant (MVP)", layout="wide")

st.title("AI-Powered Support Communication Assistant — MVP")
st.caption("Offline demo: filter → analyze → prioritize → draft replies → dashboard stats")

# Load data
default_path = st.sidebar.text_input("Path to CSV emails", value="/mnt/data/68b1acd44f393_Sample_Support_Emails_Dataset (2).csv")
kb_path = st.sidebar.text_input("Path to Knowledge Base", value=str(Path(__file__).parent / "knowledge_base.md"))
kb_chunks = load_kb(Path(kb_path))

@st.cache_data(show_spinner=False)
def load_emails(path: str) -> pd.DataFrame:
    try:
        df = pd.read_csv(path)
    except Exception:
        df = pd.DataFrame([
            {"from_addr":"alice@example.com","subject":"Support: cannot access dashboard","body":"I cannot access my dashboard immediately. Please help.","received_at":pd.Timestamp.utcnow()},
            {"from_addr":"bob@example.com","subject":"Request: refund for order 1234","body":"Hi team, requesting a refund ASAP. Thanks.","received_at":pd.Timestamp.utcnow()},
            {"from_addr":"carol@example.com","subject":"Hello","body":"Just saying hi.","received_at":pd.Timestamp.utcnow()},
        ])
    return normalize_input_df(df)

df = load_emails(default_path)

# Filter support-like subjects
mask = df["subject"].fillna("").str.contains(SUPPORT_SUBJECT_RE)
support_df = df[mask].copy()

# Analyze
records = []
for _, row in support_df.iterrows():
    text = f"{row.subject}\n{row.body}"
    sent = simple_sentiment(text)
    prio, score = priority_score(text, sent)
    info = extract_info(text, row.from_addr)
    snippets = retrieve_kb_snippets(kb_chunks, text, k=3)
    draft = draft_reply({
        "from_addr": row.from_addr,
        "subject": row.subject,
        "body": row.body,
        "sentiment": sent,
        "priority": prio
    }, snippets)
    records.append({
        "from_addr": row.from_addr,
        "subject": row.subject,
        "received_at": row.received_at,
        "sentiment": sent,
        "priority": prio,
        "score": score,
        "phone": info["phone"],
        "alt_email": info["alt_email"],
        "requirements": info["requirements"],
        "draft": draft
    })

out = pd.DataFrame(records)
if out.empty:
    st.info("No support-like emails found (subjects must contain support/query/request/help).")
    st.stop()

# Stats
col1, col2, col3, col4 = st.columns(4)
with col1: st.metric("Total (filtered)", len(out))
with col2: st.metric("Urgent", int((out['priority']=='urgent').sum()))
with col3: st.metric("Negative", int((out['sentiment']=='negative').sum()))
with col4: st.metric("Last 24h", int((pd.to_datetime(out['received_at']) > (pd.Timestamp.utcnow() - pd.Timedelta('1D'))).sum()))

# Sort by priority score (desc) so urgent first
out_sorted = out.sort_values(by=["priority","score"], ascending=[True, False])  # 'not_urgent' < 'urgent' so fix:
# Make 'urgent' appear first explicitly
out_sorted["prio_num"] = out_sorted["priority"].map({"urgent":0, "not_urgent":1})
out_sorted = out_sorted.sort_values(by=["prio_num","score"], ascending=[True, False]).drop(columns=["prio_num"])

# Table
st.subheader("Inbox — Prioritized")
st.dataframe(out_sorted[["from_addr","subject","received_at","sentiment","priority","score","phone","alt_email"]], use_container_width=True, height=320)

# Detail + Draft editor
st.subheader("Email Detail & Draft Reply")
idx = st.selectbox("Select an email", options=list(out_sorted.index), format_func=lambda i: f"{out_sorted.loc[i,'from_addr']} — {out_sorted.loc[i,'subject'][:60]}")
row = out_sorted.loc[idx]

with st.expander("Raw email body"):
    st.write(df.loc[df['subject']==row['subject']].iloc[0]['body'])

st.markdown(f"**Detected Sentiment:** {row['sentiment']}  •  **Priority:** {row['priority']}  •  **Score:** {row['score']}")
st.markdown(f"**Extracted:** Phone: `{row['phone']}`  •  Alt Email: `{row['alt_email']}`")
draft_text = st.text_area("AI Draft (editable before sending)", value=row["draft"], height=260)

colA, colB = st.columns([1,1])
with colA:
    if st.button("Mark as Sent (simulate)"):
        st.success("Marked as sent ✅ (simulation). In production, integrate SMTP/Gmail API here.")
with colB:
    if st.button("Regenerate Draft (local rules)"):
        st.rerun()

st.caption("Note: This MVP uses offline, rule-based analysis and simple KB retrieval for demo. Swap in LLM and real email APIs for production.")
