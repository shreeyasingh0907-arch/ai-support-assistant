
# AI-Powered Support Communication Assistant — MVP (Offline)

This is a minimal, offline prototype that demonstrates the end-to-end flow:
- Load emails from a CSV
- Filter support-like subjects
- Analyze (rule-based sentiment, priority)
- Extract info (phone, alt email)
- Retrieve knowledge snippets (simple keyword overlap)
- Draft a professional response
- Show a dashboard to review/edit before sending

> Replace the analyzers and draft generator with real ML/LLM (OpenAI/HF) and plug in Gmail/Outlook APIs for production.

## Quickstart

1. Create a virtual environment (optional) and install deps:
```bash
pip install -r requirements.txt
```

2. Run the Streamlit app:
```bash
streamlit run streamlit_app.py
```

3. By default, it loads your uploaded CSV:
```
/mnt/data/68b1acd44f393_Sample_Support_Emails_Dataset (2).csv
```
You can change the path in the app sidebar.

## Files
- `streamlit_app.py` — main dashboard
- `knowledge_base.md` — tiny demo KB used for context-aware drafting
- `requirements.txt` — minimal dependencies
- `README.md`

## Next Steps (Prod)
- **Email APIs**: Gmail API / Outlook Graph / IMAP poller
- **LLM**: Use GPT or HF for sentiment, extraction, and drafting with better prompts
- **RAG**: Store KB in FAISS/Chroma, embed with sentence-transformers
- **DB**: SQLite/Postgres for persistence (emails, drafts, sent status)
- **Queue**: Redis priority queues for scaling
- **Send**: SMTP/Gmail API to send replies after approval

